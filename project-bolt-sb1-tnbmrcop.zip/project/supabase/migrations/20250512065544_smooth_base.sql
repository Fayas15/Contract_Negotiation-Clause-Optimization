/*
  # Initial schema for ContractAI platform

  1. New Tables
    - `contracts`
      - Core contract information and metadata
      - Stores contract documents, status, and risk levels
    - `clauses`
      - Individual contract clauses
      - Links to parent contract
      - Stores original and optimized text
    - `clause_templates`
      - Reusable clause templates
      - Categorized by type and industry
    - `clause_analyses`
      - AI analysis results for clauses
      - Stores risk assessments and recommendations

  2. Security
    - Enable RLS on all tables
    - Policies for authenticated users to access their contracts
    - Public read access for clause templates
*/

-- Create contracts table
CREATE TABLE IF NOT EXISTS contracts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  status text NOT NULL CHECK (status IN ('draft', 'in_progress', 'optimized', 'needs_review')),
  risk_level text NOT NULL CHECK (risk_level IN ('low', 'medium', 'high')),
  content text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  user_id uuid REFERENCES auth.users(id),
  parties jsonb DEFAULT '[]'::jsonb
);

-- Create clauses table
CREATE TABLE IF NOT EXISTS clauses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_id uuid REFERENCES contracts(id) ON DELETE CASCADE,
  title text NOT NULL,
  category text NOT NULL,
  risk_level text NOT NULL CHECK (risk_level IN ('low', 'medium', 'high')),
  priority text NOT NULL CHECK (priority IN ('low', 'medium', 'high')),
  original_text text NOT NULL,
  optimized_text text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create clause templates table
CREATE TABLE IF NOT EXISTS clause_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  category text NOT NULL,
  category_name text NOT NULL,
  risk_level text NOT NULL CHECK (risk_level IN ('low', 'medium', 'high')),
  industry text NOT NULL,
  text text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create clause analyses table
CREATE TABLE IF NOT EXISTS clause_analyses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  clause_id uuid REFERENCES clauses(id) ON DELETE CASCADE,
  analysis text NOT NULL,
  recommendation text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE contracts ENABLE ROW LEVEL SECURITY;
ALTER TABLE clauses ENABLE ROW LEVEL SECURITY;
ALTER TABLE clause_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE clause_analyses ENABLE ROW LEVEL SECURITY;

-- Policies for contracts
CREATE POLICY "Users can view own contracts"
  ON contracts
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own contracts"
  ON contracts
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own contracts"
  ON contracts
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Policies for clauses
CREATE POLICY "Users can view clauses of own contracts"
  ON clauses
  FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM contracts
    WHERE contracts.id = clauses.contract_id
    AND contracts.user_id = auth.uid()
  ));

CREATE POLICY "Users can modify clauses of own contracts"
  ON clauses
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM contracts
    WHERE contracts.id = clauses.contract_id
    AND contracts.user_id = auth.uid()
  ));

-- Policies for clause templates
CREATE POLICY "Everyone can view clause templates"
  ON clause_templates
  FOR SELECT
  TO authenticated
  USING (true);

-- Policies for clause analyses
CREATE POLICY "Users can view analyses of own contract clauses"
  ON clause_analyses
  FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM clauses
    JOIN contracts ON contracts.id = clauses.contract_id
    WHERE clause_analyses.clause_id = clauses.id
    AND contracts.user_id = auth.uid()
  ));