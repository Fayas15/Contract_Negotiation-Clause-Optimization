import { Contract, Clause, ClauseTemplate } from '../types/contract';

export const mockContracts: Contract[] = [
  {
    id: '1',
    title: 'Service Agreement with XYZ Corp',
    description: 'Professional services contract for software development',
    status: 'optimized',
    riskLevel: 'low',
    lastModified: '2 days ago',
    parties: ['XYZ Corp', 'Your Company'],
    clauses: 18
  },
  {
    id: '2',
    title: 'Software License Agreement',
    description: 'Enterprise license for cloud software suite',
    status: 'in_progress',
    riskLevel: 'medium',
    lastModified: '5 days ago',
    parties: ['ABC Inc', 'Your Company', 'Third Party'],
    clauses: 24
  },
  {
    id: '3',
    title: 'Vendor Agreement',
    description: 'Agreement with hardware supplier for equipment',
    status: 'needs_review',
    riskLevel: 'high',
    lastModified: '1 week ago',
    parties: ['Hardware Supplier', 'Your Company'],
    clauses: 15
  }
];

export const mockClauses: Clause[] = [
  {
    id: '1',
    title: 'Liability Limitation',
    category: 'liability',
    riskLevel: 'high',
    priority: 'high',
    originalText: 'Provider\'s liability shall be limited to the amount paid by Client to Provider under this Agreement during the twelve (12) months preceding the event giving rise to the claim.',
    optimizedText: 'Provider\'s liability shall be limited to two (2) times the amount paid by Client to Provider under this Agreement during the twelve (12) months preceding the event giving rise to the claim. This limitation shall not apply to Provider\'s indemnification obligations or Provider\'s breach of its confidentiality obligations.',
    analysis: 'The original clause limits liability too severely, capping it at just the fees paid over the last 12 months. This provides inadequate protection if a serious breach or error occurs.',
    recommendation: 'Negotiate for a higher liability cap (2-3x annual contract value) and exclusions for indemnification and confidentiality breaches, which should not be subject to the cap.'
  },
  {
    id: '2',
    title: 'Payment Terms',
    category: 'payment',
    riskLevel: 'medium',
    priority: 'medium',
    originalText: 'Client shall pay each invoice within thirty (30) days of receipt. No interest shall accrue on late payments.',
    optimizedText: 'Client shall pay each invoice within fifteen (15) days of receipt. Late payments shall accrue interest at a rate of 1.5% per month or the maximum allowed by law, whichever is less.',
    analysis: 'The original payment terms are unfavorable, with a long 30-day window and no consequences for late payment, which could impact cash flow and create incentives for delayed payment.',
    recommendation: 'Shorten the payment window to 15 days and add an interest charge for late payments to encourage timely payment and protect your cash flow.'
  },
  {
    id: '3',
    title: 'Intellectual Property Rights',
    category: 'ip',
    riskLevel: 'high',
    priority: 'high',
    originalText: 'Provider shall retain ownership of all intellectual property created in connection with the Services, and Client shall have a non-exclusive license to use such intellectual property for its internal business purposes.',
    optimizedText: 'Client shall own all intellectual property specifically created for Client in connection with the Services upon payment in full. Provider shall retain ownership of all pre-existing intellectual property and general know-how, and Client shall have a perpetual, worldwide, non-exclusive license to use such pre-existing intellectual property as necessary to use the deliverables.',
    analysis: 'The original clause gives the provider ownership of all IP created during the project, which is unusual for a custom development agreement where the client is paying for work product specifically created for them.',
    recommendation: 'Negotiate for full ownership of all work product created specifically for you, while allowing the provider to retain ownership of pre-existing IP and general methods/know-how.'
  },
  {
    id: '4',
    title: 'Termination Rights',
    category: 'termination',
    riskLevel: 'medium',
    priority: 'medium',
    originalText: 'Either party may terminate this Agreement for cause if the other party materially breaches this Agreement and fails to cure such breach within sixty (60) days after receiving written notice of the breach.',
    optimizedText: 'Either party may terminate this Agreement: (a) for convenience upon thirty (30) days written notice; or (b) for cause if the other party materially breaches this Agreement and fails to cure such breach within thirty (30) days after receiving written notice of the breach. Client may terminate immediately in the event of Provider\'s violation of confidentiality obligations.',
    analysis: 'The original termination clause only allows for termination in case of uncured material breach with a lengthy 60-day cure period, locking both parties into the agreement regardless of changing circumstances.',
    recommendation: 'Add termination for convenience with 30 days notice, shorten the cure period to 30 days, and add immediate termination rights for critical breaches like confidentiality violations.'
  }
];

export const mockTemplates: ClauseTemplate[] = [
  {
    id: '1',
    title: 'Standard Liability Limitation',
    description: 'A balanced limitation of liability clause suitable for most service agreements',
    category: 'liability',
    categoryName: 'Liability',
    riskLevel: 'medium',
    industry: 'General',
    text: 'Provider\'s liability shall be limited to two (2) times the amount paid by Client to Provider under this Agreement during the twelve (12) months preceding the event giving rise to the claim. This limitation shall not apply to Provider\'s indemnification obligations or Provider\'s breach of its confidentiality obligations.'
  },
  {
    id: '2',
    title: 'Strict Liability Limitation',
    description: 'Stronger liability protection for high-risk service providers',
    category: 'liability',
    categoryName: 'Liability',
    riskLevel: 'high',
    industry: 'Technology',
    text: 'Provider\'s aggregate liability arising out of or related to this Agreement shall not exceed the amount paid by Client to Provider under this Agreement during the six (6) months preceding the event giving rise to the claim. In no event shall Provider be liable for any indirect, incidental, special, consequential or punitive damages, including loss of profits, data, or business opportunities.'
  },
  {
    id: '3',
    title: 'Standard Payment Terms',
    description: 'Balanced payment terms with reasonable timelines',
    category: 'payment',
    categoryName: 'Payment Terms',
    riskLevel: 'low',
    industry: 'General',
    text: 'Client shall pay each invoice within fifteen (15) days of receipt. Late payments shall accrue interest at a rate of 1.5% per month or the maximum allowed by law, whichever is less.'
  },
  {
    id: '4',
    title: 'Enterprise IP Rights',
    description: 'IP terms for enterprise software development',
    category: 'ip',
    categoryName: 'Intellectual Property',
    riskLevel: 'medium',
    industry: 'Technology',
    text: 'Client shall own all intellectual property specifically created for Client in connection with the Services upon payment in full. Provider shall retain ownership of all pre-existing intellectual property and general know-how, and Client shall have a perpetual, worldwide, non-exclusive license to use such pre-existing intellectual property as necessary to use the deliverables.'
  },
  {
    id: '5',
    title: 'Confidentiality (Standard)',
    description: 'Standard confidentiality provisions for business agreements',
    category: 'confidentiality',
    categoryName: 'Confidentiality',
    riskLevel: 'medium',
    industry: 'General',
    text: 'Each party shall protect the other party\'s Confidential Information with the same degree of care as it uses to protect its own confidential information, but in no event less than reasonable care, and shall not disclose such Confidential Information to any third party except as necessary to perform its obligations under this Agreement or as required by law.'
  },
  {
    id: '6',
    title: 'Termination with Convenience',
    description: 'Flexible termination rights for both parties',
    category: 'termination',
    categoryName: 'Termination',
    riskLevel: 'low',
    industry: 'General',
    text: 'Either party may terminate this Agreement: (a) for convenience upon thirty (30) days written notice; or (b) for cause if the other party materially breaches this Agreement and fails to cure such breach within thirty (30) days after receiving written notice of the breach.'
  },
  {
    id: '7',
    title: 'Governing Law (Neutral)',
    description: 'Neutral governing law provision for international contracts',
    category: 'governance',
    categoryName: 'Governance',
    riskLevel: 'low',
    industry: 'International',
    text: 'This Agreement shall be governed by the laws of the State of Delaware, without regard to its conflict of laws principles. The parties consent to the exclusive jurisdiction of the state and federal courts located in Delaware for resolution of any disputes arising out of this Agreement.'
  }
];