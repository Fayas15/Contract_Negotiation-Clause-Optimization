import React, { useState } from 'react';
import { AlertTriangle, CheckCircle, ThumbsUp, ThumbsDown, HelpCircle } from 'lucide-react';
import { Clause } from '../types/contract';

interface ClauseComparisonCardProps {
  clause: Clause;
}

const ClauseComparisonCard: React.FC<ClauseComparisonCardProps> = ({ clause }) => {
  const [feedbackSent, setFeedbackSent] = useState(false);

  const getRiskBadge = (riskLevel: string) => {
    switch (riskLevel) {
      case 'high':
        return (
          <div className="flex items-center px-2 py-1 bg-red-100 text-red-800 rounded-full text-xs font-medium">
            <AlertTriangle className="h-3 w-3 mr-1" />
            High Risk
          </div>
        );
      case 'medium':
        return (
          <div className="flex items-center px-2 py-1 bg-amber-100 text-amber-800 rounded-full text-xs font-medium">
            <AlertTriangle className="h-3 w-3 mr-1" />
            Medium Risk
          </div>
        );
      case 'low':
        return (
          <div className="flex items-center px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs font-medium">
            <CheckCircle className="h-3 w-3 mr-1" />
            Low Risk
          </div>
        );
      default:
        return null;
    }
  };

  const handleFeedback = (isPositive: boolean) => {
    // In a real app, this would send feedback to the server
    setFeedbackSent(true);
  };

  return (
    <div className="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden">
      <div className="border-b border-gray-200 px-6 py-4 bg-gray-50 flex items-center justify-between">
        <div className="flex items-center">
          <h3 className="text-base font-medium text-gray-900 mr-3">{clause.title}</h3>
          {getRiskBadge(clause.riskLevel)}
        </div>
        <div className="flex items-center space-x-2">
          {!feedbackSent ? (
            <>
              <button 
                onClick={() => handleFeedback(true)}
                className="p-1 rounded-full text-gray-400 hover:text-green-500 hover:bg-green-50 transition-colors duration-200"
                title="This recommendation is helpful"
              >
                <ThumbsUp className="h-5 w-5" />
              </button>
              <button 
                onClick={() => handleFeedback(false)}
                className="p-1 rounded-full text-gray-400 hover:text-red-500 hover:bg-red-50 transition-colors duration-200"
                title="This recommendation is not helpful"
              >
                <ThumbsDown className="h-5 w-5" />
              </button>
            </>
          ) : (
            <span className="text-xs text-gray-500">Thanks for your feedback</span>
          )}
        </div>
      </div>
      
      <div className="p-6 grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div className="flex items-center">
            <div className="h-2 w-2 rounded-full bg-red-500 mr-2"></div>
            <h4 className="text-sm font-medium text-gray-900">Original Clause</h4>
          </div>
          <div className="bg-red-50 border border-red-100 rounded-lg p-4">
            <p className="text-sm text-gray-800">{clause.originalText}</p>
          </div>
        </div>
        
        <div className="space-y-4">
          <div className="flex items-center">
            <div className="h-2 w-2 rounded-full bg-green-500 mr-2"></div>
            <h4 className="text-sm font-medium text-gray-900">Optimized Clause</h4>
          </div>
          <div className="bg-green-50 border border-green-100 rounded-lg p-4">
            <p className="text-sm text-gray-800">{clause.optimizedText}</p>
          </div>
        </div>
      </div>
      
      <div className="px-6 py-4 bg-blue-50 border-t border-blue-100">
        <div className="flex items-start">
          <HelpCircle className="h-5 w-5 text-blue-500 mr-3 mt-0.5 flex-shrink-0" />
          <div>
            <h4 className="text-sm font-medium text-blue-900">AI Analysis</h4>
            <p className="text-sm text-blue-700 mt-1">{clause.analysis}</p>
          </div>
        </div>
      </div>
      
      <div className="px-6 py-4 border-t border-gray-200 bg-gray-50">
        <div className="flex items-center justify-between">
          <h4 className="text-sm font-medium text-gray-900">Negotiation Recommendation</h4>
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
            clause.priority === 'high' 
              ? 'bg-red-100 text-red-800' 
              : clause.priority === 'medium'
                ? 'bg-amber-100 text-amber-800'
                : 'bg-green-100 text-green-800'
          }`}>
            {clause.priority.charAt(0).toUpperCase() + clause.priority.slice(1)} Priority
          </span>
        </div>
        <p className="text-sm text-gray-700 mt-2">{clause.recommendation}</p>
      </div>
    </div>
  );
};

export default ClauseComparisonCard;