import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  FileText,
  Book,
  History,
  Settings,
  HelpCircle,
  Scale,
  Sparkles
} from 'lucide-react';

const Sidebar: React.FC = () => {
  return (
    <aside className="w-64 bg-blue-900 text-white flex flex-col h-screen sticky top-0">
      <div className="p-6 flex items-center gap-3">
        <Scale className="h-7 w-7" />
        <div>
          <h1 className="text-xl font-bold">ContractAI</h1>
          <div className="flex items-center mt-1">
            <Sparkles className="h-3 w-3 mr-1" />
            <span className="text-xs text-blue-200">Powered by AI</span>
          </div>
        </div>
      </div>
      <nav className="flex-1 px-4 py-2">
        <ul className="space-y-1">
          <li>
            <NavLink
              to="/"
              className={({ isActive }) =>
                `flex items-center px-4 py-3 text-sm font-medium rounded-md transition-all ${
                  isActive
                    ? 'bg-blue-800 text-white'
                    : 'text-blue-100 hover:bg-blue-800 hover:text-white'
                }`
              }
            >
              <LayoutDashboard className="h-5 w-5 mr-3" />
              Dashboard
            </NavLink>
          </li>
          <li>
            <NavLink
              to="/analysis/new"
              className={({ isActive }) =>
                `flex items-center px-4 py-3 text-sm font-medium rounded-md transition-all ${
                  isActive
                    ? 'bg-blue-800 text-white'
                    : 'text-blue-100 hover:bg-blue-800 hover:text-white'
                }`
              }
            >
              <FileText className="h-5 w-5 mr-3" />
              New Analysis
            </NavLink>
          </li>
          <li>
            <NavLink
              to="/library"
              className={({ isActive }) =>
                `flex items-center px-4 py-3 text-sm font-medium rounded-md transition-all ${
                  isActive
                    ? 'bg-blue-800 text-white'
                    : 'text-blue-100 hover:bg-blue-800 hover:text-white'
                }`
              }
            >
              <Book className="h-5 w-5 mr-3" />
              Clause Library
            </NavLink>
          </li>
          <li>
            <NavLink
              to="/history"
              className={({ isActive }) =>
                `flex items-center px-4 py-3 text-sm font-medium rounded-md transition-all ${
                  isActive
                    ? 'bg-blue-800 text-white'
                    : 'text-blue-100 hover:bg-blue-800 hover:text-white'
                }`
              }
            >
              <History className="h-5 w-5 mr-3" />
              History
            </NavLink>
          </li>
        </ul>
      </nav>
      <div className="p-4 border-t border-blue-800">
        <ul className="space-y-1">
          <li>
            <NavLink
              to="/settings"
              className="flex items-center px-4 py-3 text-sm font-medium rounded-md text-blue-100 hover:bg-blue-800 hover:text-white transition-all"
            >
              <Settings className="h-5 w-5 mr-3" />
              Settings
            </NavLink>
          </li>
          <li>
            <NavLink
              to="/help"
              className="flex items-center px-4 py-3 text-sm font-medium rounded-md text-blue-100 hover:bg-blue-800 hover:text-white transition-all"
            >
              <HelpCircle className="h-5 w-5 mr-3" />
              Help & Support
            </NavLink>
          </li>
        </ul>
      </div>
    </aside>
  );
};

export default Sidebar;