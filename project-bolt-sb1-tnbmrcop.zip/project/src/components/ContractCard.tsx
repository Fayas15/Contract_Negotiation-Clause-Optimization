import React from 'react';
import { Link } from 'react-router-dom';
import { Clock, AlertTriangle, CheckCircle } from 'lucide-react';
import { Contract } from '../types/contract';

interface ContractCardProps {
  contract: Contract;
}

const ContractCard: React.FC<ContractCardProps> = ({ contract }) => {
  const getRiskBadge = (riskLevel: string) => {
    const baseClasses = "px-2 py-1 text-xs font-medium rounded-full";
    
    switch (riskLevel) {
      case 'high':
        return (
          <span className={`${baseClasses} bg-red-100 text-red-800`}>
            High Risk
          </span>
        );
      case 'medium':
        return (
          <span className={`${baseClasses} bg-amber-100 text-amber-800`}>
            Medium Risk
          </span>
        );
      case 'low':
        return (
          <span className={`${baseClasses} bg-green-100 text-green-800`}>
            Low Risk
          </span>
        );
      default:
        return null;
    }
  };

  const getStatusIndicator = (status: string) => {
    switch (status) {
      case 'optimized':
        return (
          <div className="flex items-center text-green-600">
            <CheckCircle className="h-4 w-4 mr-1" />
            <span className="text-xs font-medium">Optimized</span>
          </div>
        );
      case 'in_progress':
        return (
          <div className="flex items-center text-amber-600">
            <Clock className="h-4 w-4 mr-1" />
            <span className="text-xs font-medium">In Progress</span>
          </div>
        );
      case 'needs_review':
        return (
          <div className="flex items-center text-blue-600">
            <AlertTriangle className="h-4 w-4 mr-1" />
            <span className="text-xs font-medium">Needs Review</span>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <Link 
      to={`/analysis/${contract.id}`} 
      className="bg-white rounded-lg shadow border border-gray-200 hover:shadow-md transition-shadow duration-200 overflow-hidden flex flex-col"
    >
      <div className="p-5 flex-1">
        <div className="flex justify-between items-start mb-3">
          <h3 className="text-base font-semibold text-gray-900 truncate">{contract.title}</h3>
          {getRiskBadge(contract.riskLevel)}
        </div>
        <p className="text-sm text-gray-500 mb-4 line-clamp-2">{contract.description}</p>
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="relative flex -space-x-2">
              {contract.parties.map((party, index) => (
                <div 
                  key={index} 
                  className="h-6 w-6 rounded-full bg-gray-200 border-2 border-white flex items-center justify-center overflow-hidden"
                >
                  <span className="text-xs font-medium text-gray-600">{party.charAt(0).toUpperCase()}</span>
                </div>
              ))}
            </div>
            <span className="text-xs text-gray-500 ml-2">{contract.parties.length} Parties</span>
          </div>
          {getStatusIndicator(contract.status)}
        </div>
      </div>
      <div className="border-t border-gray-200 px-5 py-3 bg-gray-50 text-xs text-gray-500 flex justify-between items-center">
        <span>Modified {contract.lastModified}</span>
        <span>{contract.clauses} clauses</span>
      </div>
    </Link>
  );
};

export default ContractCard;