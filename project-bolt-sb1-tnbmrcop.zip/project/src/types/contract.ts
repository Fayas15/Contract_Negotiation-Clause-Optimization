export interface Contract {
  id: string;
  title: string;
  description: string;
  status: 'optimized' | 'in_progress' | 'needs_review';
  riskLevel: 'high' | 'medium' | 'low';
  lastModified: string;
  parties: string[];
  clauses: number;
}

export interface Clause {
  id: string;
  title: string;
  category: string;
  riskLevel: 'high' | 'medium' | 'low';
  priority: 'high' | 'medium' | 'low';
  originalText: string;
  optimizedText: string;
  analysis: string;
  recommendation: string;
}

export interface ClauseTemplate {
  id: string;
  title: string;
  description: string;
  category: string;
  categoryName: string;
  riskLevel: 'high' | 'medium' | 'low';
  industry: string;
  text: string;
}