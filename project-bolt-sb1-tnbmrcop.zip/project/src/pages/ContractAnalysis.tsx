import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { 
  FileText, 
  AlertTriangle, 
  CheckCircle, 
  Info, 
  ChevronLeft, 
  ChevronRight,
  Download, 
  Share2
} from 'lucide-react';
import ClauseComparisonCard from '../components/ClauseComparisonCard';
import { mockClauses } from '../data/mockData';

const ContractAnalysis: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [activeTab, setActiveTab] = useState('analysis');
  const [selectedClauseIndex, setSelectedClauseIndex] = useState(0);
  
  const isNewAnalysis = id === 'new';

  const handlePrevClause = () => {
    if (selectedClauseIndex > 0) {
      setSelectedClauseIndex(selectedClauseIndex - 1);
    }
  };

  const handleNextClause = () => {
    if (selectedClauseIndex < mockClauses.length - 1) {
      setSelectedClauseIndex(selectedClauseIndex + 1);
    }
  };

  if (isNewAnalysis) {
    return (
      <div className="max-w-5xl mx-auto bg-white rounded-lg shadow-sm border border-gray-200 p-8">
        <h1 className="text-2xl font-bold text-gray-900 mb-6">New Contract Analysis</h1>
        
        <div className="mb-8 border-b border-gray-200 pb-6">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Upload Contract</h2>
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-12 text-center hover:border-blue-500 transition-colors duration-200 cursor-pointer">
            <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 mb-2">Drag and drop your contract file here</p>
            <p className="text-gray-500 text-sm mb-4">Supported formats: PDF, DOCX, TXT</p>
            <button className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-200">
              Browse Files
            </button>
          </div>
        </div>

        <div className="mb-8">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Contract Details</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label htmlFor="contractName" className="block text-sm font-medium text-gray-700 mb-1">
                Contract Name
              </label>
              <input
                type="text"
                id="contractName"
                className="block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                placeholder="E.g., Software Development Agreement"
              />
            </div>
            <div>
              <label htmlFor="contractType" className="block text-sm font-medium text-gray-700 mb-1">
                Contract Type
              </label>
              <select
                id="contractType"
                className="block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
              >
                <option value="">Select contract type</option>
                <option value="service">Service Agreement</option>
                <option value="employment">Employment Contract</option>
                <option value="nda">Non-Disclosure Agreement</option>
                <option value="license">License Agreement</option>
                <option value="sales">Sales Contract</option>
                <option value="custom">Custom</option>
              </select>
            </div>
          </div>
        </div>

        <div className="mb-8">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Optimization Preferences</h2>
          <div className="space-y-4">
            <div className="flex items-center">
              <input
                id="comprehensive"
                name="analysis_type"
                type="radio"
                defaultChecked
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
              />
              <label htmlFor="comprehensive" className="ml-3">
                <span className="block text-sm font-medium text-gray-700">Comprehensive Analysis</span>
                <span className="block text-sm text-gray-500">Review all clauses with detailed recommendations</span>
              </label>
            </div>
            <div className="flex items-center">
              <input
                id="quick"
                name="analysis_type"
                type="radio"
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
              />
              <label htmlFor="quick" className="ml-3">
                <span className="block text-sm font-medium text-gray-700">Quick Analysis</span>
                <span className="block text-sm text-gray-500">Focus on high-risk clauses only</span>
              </label>
            </div>
            <div className="flex items-center">
              <input
                id="custom"
                name="analysis_type"
                type="radio"
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
              />
              <label htmlFor="custom" className="ml-3">
                <span className="block text-sm font-medium text-gray-700">Custom Analysis</span>
                <span className="block text-sm text-gray-500">Select specific clauses or topics to focus on</span>
              </label>
            </div>
          </div>
        </div>

        <div className="flex justify-end">
          <button
            type="button"
            className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-200"
          >
            Start Analysis
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Service Agreement Analysis</h1>
        <div className="flex space-x-3">
          <button className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-200">
            <Download className="h-4 w-4 mr-2" />
            Export
          </button>
          <button className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-200">
            <Share2 className="h-4 w-4 mr-2" />
            Share
          </button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex" aria-label="Tabs">
            <button
              onClick={() => setActiveTab('analysis')}
              className={`${
                activeTab === 'analysis'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              } w-1/4 py-4 px-1 text-center border-b-2 font-medium text-sm`}
            >
              Analysis
            </button>
            <button
              onClick={() => setActiveTab('original')}
              className={`${
                activeTab === 'original'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              } w-1/4 py-4 px-1 text-center border-b-2 font-medium text-sm`}
            >
              Original Contract
            </button>
            <button
              onClick={() => setActiveTab('optimized')}
              className={`${
                activeTab === 'optimized'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              } w-1/4 py-4 px-1 text-center border-b-2 font-medium text-sm`}
            >
              Optimized Contract
            </button>
            <button
              onClick={() => setActiveTab('summary')}
              className={`${
                activeTab === 'summary'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              } w-1/4 py-4 px-1 text-center border-b-2 font-medium text-sm`}
            >
              Summary Report
            </button>
          </nav>
        </div>

        {activeTab === 'analysis' && (
          <div className="p-6">
            <div className="mb-6 bg-blue-50 p-4 rounded-lg border border-blue-100 flex items-start">
              <Info className="h-5 w-5 text-blue-500 mr-3 mt-0.5 flex-shrink-0" />
              <div>
                <h3 className="text-sm font-medium text-blue-800">Analysis Completed</h3>
                <p className="text-sm text-blue-600 mt-1">
                  We've analyzed your contract and found 3 high-risk clauses and 5 clauses that could be optimized for better terms.
                </p>
              </div>
            </div>

            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-medium text-gray-900">
                Clause {selectedClauseIndex + 1} of {mockClauses.length}
              </h2>
              <div className="flex space-x-2">
                <button
                  onClick={handlePrevClause}
                  disabled={selectedClauseIndex === 0}
                  className={`p-1 rounded-full ${
                    selectedClauseIndex === 0
                      ? 'text-gray-300 cursor-not-allowed'
                      : 'text-gray-500 hover:bg-gray-100'
                  }`}
                >
                  <ChevronLeft className="h-6 w-6" />
                </button>
                <button
                  onClick={handleNextClause}
                  disabled={selectedClauseIndex === mockClauses.length - 1}
                  className={`p-1 rounded-full ${
                    selectedClauseIndex === mockClauses.length - 1
                      ? 'text-gray-300 cursor-not-allowed'
                      : 'text-gray-500 hover:bg-gray-100'
                  }`}
                >
                  <ChevronRight className="h-6 w-6" />
                </button>
              </div>
            </div>

            <ClauseComparisonCard clause={mockClauses[selectedClauseIndex]} />

            <div className="flex justify-between mt-6">
              <button
                onClick={handlePrevClause}
                disabled={selectedClauseIndex === 0}
                className={`inline-flex items-center px-4 py-2 border ${
                  selectedClauseIndex === 0
                    ? 'border-gray-200 text-gray-400 cursor-not-allowed'
                    : 'border-gray-300 text-gray-700 hover:bg-gray-50'
                } text-sm font-medium rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-200`}
              >
                <ChevronLeft className="h-4 w-4 mr-2" />
                Previous Clause
              </button>
              <button
                onClick={handleNextClause}
                disabled={selectedClauseIndex === mockClauses.length - 1}
                className={`inline-flex items-center px-4 py-2 border ${
                  selectedClauseIndex === mockClauses.length - 1
                    ? 'border-gray-200 text-gray-400 cursor-not-allowed'
                    : 'border-gray-300 text-gray-700 hover:bg-gray-50'
                } text-sm font-medium rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-200`}
              >
                Next Clause
                <ChevronRight className="h-4 w-4 ml-2" />
              </button>
            </div>
          </div>
        )}

        {activeTab === 'original' && (
          <div className="p-6">
            <div className="mb-4 flex justify-between items-center">
              <h2 className="text-lg font-medium text-gray-900">Original Contract</h2>
              <button className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-200">
                <Download className="h-4 w-4 mr-2" />
                Download Original
              </button>
            </div>
            <div className="rounded-lg border border-gray-200 bg-gray-50 p-6">
              <h3 className="text-base font-medium text-gray-900 mb-2">Service Agreement</h3>
              <p className="text-sm text-gray-500 mb-4">Effective Date: May 15, 2025</p>
              
              <div className="prose max-w-none text-gray-600">
                <p className="mb-4">
                  This Service Agreement (the "Agreement") is entered into as of the Effective Date by and between XYZ Corporation, a Delaware corporation ("Client"), and ABC Provider Inc., a California corporation ("Provider").
                </p>
                
                <p className="font-medium mb-2">1. Services</p>
                <p className="mb-4">
                  Provider shall perform the services described in Exhibit A (the "Services") for Client. Provider shall perform the Services in accordance with the terms and conditions of this Agreement.
                </p>
                
                <p className="font-medium mb-2">2. Payment</p>
                <p className="mb-4">
                  Client shall pay Provider for the Services in accordance with the fee schedule set forth in Exhibit B. Provider shall invoice Client monthly for Services performed during the preceding month. Client shall pay each invoice within thirty (30) days of receipt.
                </p>
                
                <p className="text-sm text-gray-400 italic">
                  [Full contract content would appear here]
                </p>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'optimized' && (
          <div className="p-6">
            <div className="mb-4 flex justify-between items-center">
              <h2 className="text-lg font-medium text-gray-900">Optimized Contract</h2>
              <button className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-200">
                <Download className="h-4 w-4 mr-2" />
                Download Optimized
              </button>
            </div>
            <div className="rounded-lg border border-gray-200 bg-gray-50 p-6">
              <h3 className="text-base font-medium text-gray-900 mb-2">Service Agreement</h3>
              <p className="text-sm text-gray-500 mb-4">Optimized Version - May 18, 2025</p>
              
              <div className="prose max-w-none text-gray-600">
                <p className="mb-4">
                  This Service Agreement (the "Agreement") is entered into as of the Effective Date by and between XYZ Corporation, a Delaware corporation ("Client"), and ABC Provider Inc., a California corporation ("Provider").
                </p>
                
                <p className="font-medium mb-2">1. Services</p>
                <p className="mb-4">
                  Provider shall perform the services described in Exhibit A (the "Services") for Client. Provider shall perform the Services in a professional and workmanlike manner consistent with industry standards.
                </p>
                
                <p className="font-medium mb-2">2. Payment</p>
                <p className="mb-4 bg-green-50 border border-green-100 p-2 rounded">
                  Client shall pay Provider for the Services in accordance with the fee schedule set forth in Exhibit B. Provider shall invoice Client monthly for Services performed during the preceding month. Client shall pay each invoice within fifteen (15) days of receipt. Late payments shall accrue interest at a rate of 1.5% per month or the maximum allowed by law, whichever is less.
                </p>
                
                <p className="text-sm text-gray-400 italic">
                  [Full optimized contract content would appear here]
                </p>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'summary' && (
          <div className="p-6">
            <h2 className="text-lg font-medium text-gray-900 mb-4">Summary Report</h2>
            
            <div className="mb-6 bg-white border border-gray-200 rounded-lg overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
                <h3 className="text-base font-medium text-gray-900">Optimization Overview</h3>
              </div>
              <div className="px-6 py-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="flex flex-col items-center">
                    <div className="flex items-center justify-center h-16 w-16 rounded-full bg-blue-100 text-blue-800 font-bold text-xl mb-2">
                      12
                    </div>
                    <p className="text-sm text-gray-500">Total Clauses</p>
                  </div>
                  <div className="flex flex-col items-center">
                    <div className="flex items-center justify-center h-16 w-16 rounded-full bg-red-100 text-red-800 font-bold text-xl mb-2">
                      3
                    </div>
                    <p className="text-sm text-gray-500">High Risk Clauses</p>
                  </div>
                  <div className="flex flex-col items-center">
                    <div className="flex items-center justify-center h-16 w-16 rounded-full bg-green-100 text-green-800 font-bold text-xl mb-2">
                      8
                    </div>
                    <p className="text-sm text-gray-500">Optimized Clauses</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mb-6 bg-white border border-gray-200 rounded-lg overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
                <h3 className="text-base font-medium text-gray-900">Key Improvements</h3>
              </div>
              <div className="px-6 py-4">
                <ul className="space-y-4">
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-medium text-gray-900">Reduced payment terms from 30 to 15 days</p>
                      <p className="text-sm text-gray-500 mt-1">Improved cash flow by accelerating payment schedule and adding late payment interest.</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-medium text-gray-900">Limited liability cap increased</p>
                      <p className="text-sm text-gray-500 mt-1">Raised liability cap from 1x to 2x annual contract value, providing better protection.</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-medium text-gray-900">Enhanced IP ownership rights</p>
                      <p className="text-sm text-gray-500 mt-1">Clarified that all work product is owned exclusively by the client upon payment.</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-medium text-gray-900">Improved termination rights</p>
                      <p className="text-sm text-gray-500 mt-1">Added ability to terminate with 30 days notice without cause and immediate termination for material breach.</p>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
            
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
                <h3 className="text-base font-medium text-gray-900">Remaining Concerns</h3>
              </div>
              <div className="px-6 py-4">
                <ul className="space-y-4">
                  <li className="flex items-start">
                    <AlertTriangle className="h-5 w-5 text-amber-500 mr-3 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-medium text-gray-900">Exclusivity clause</p>
                      <p className="text-sm text-gray-500 mt-1">The exclusivity provision remains overly broad and may limit future business opportunities.</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <AlertTriangle className="h-5 w-5 text-amber-500 mr-3 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-medium text-gray-900">Governing law jurisdiction</p>
                      <p className="text-sm text-gray-500 mt-1">Current jurisdiction may be disadvantageous. Consider negotiating for a neutral venue.</p>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ContractAnalysis;