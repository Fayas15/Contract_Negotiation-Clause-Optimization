import React from 'react';
import { Link } from 'react-router-dom';
import { FileText, BarChart2, AlertTriangle, Clock, ArrowUpRight } from 'lucide-react';
import ContractCard from '../components/ContractCard';
import StatCard from '../components/StatCard';
import { mockContracts } from '../data/mockData';

const Dashboard: React.FC = () => {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <Link
          to="/analysis/new"
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-200"
        >
          New Analysis
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Active Contracts"
          value="12"
          icon={<FileText className="h-6 w-6 text-blue-500" />}
          trend="+2 this month"
          trendUp={true}
        />
        <StatCard
          title="Optimization Rate"
          value="87%"
          icon={<BarChart2 className="h-6 w-6 text-green-500" />}
          trend="+5% from last month"
          trendUp={true}
        />
        <StatCard
          title="Risk Alerts"
          value="3"
          icon={<AlertTriangle className="h-6 w-6 text-amber-500" />}
          trend="-2 from last week"
          trendUp={false}
        />
        <StatCard
          title="Avg. Negotiation Time"
          value="3.2 days"
          icon={<Clock className="h-6 w-6 text-purple-500" />}
          trend="-0.8 days this quarter"
          trendUp={false}
        />
      </div>

      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-gray-900">Recent Contracts</h2>
          <Link
            to="/contracts"
            className="text-sm text-blue-600 hover:text-blue-800 flex items-center transition-colors duration-200"
          >
            View all
            <ArrowUpRight className="ml-1 h-4 w-4" />
          </Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {mockContracts.map((contract) => (
            <ContractCard key={contract.id} contract={contract} />
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg shadow p-6 col-span-2">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Optimization Performance</h2>
          <div className="h-64 flex items-center justify-center bg-gray-50 rounded-lg border border-gray-100">
            <p className="text-gray-500">Chart visualization would appear here</p>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Top Risk Categories</h2>
          <ul className="space-y-4">
            <li className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="h-3 w-3 rounded-full bg-red-500 mr-3"></div>
                <span className="text-sm text-gray-600">Liability Clauses</span>
              </div>
              <span className="text-sm font-medium">32%</span>
            </li>
            <li className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="h-3 w-3 rounded-full bg-amber-500 mr-3"></div>
                <span className="text-sm text-gray-600">Payment Terms</span>
              </div>
              <span className="text-sm font-medium">24%</span>
            </li>
            <li className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="h-3 w-3 rounded-full bg-blue-500 mr-3"></div>
                <span className="text-sm text-gray-600">Termination Rights</span>
              </div>
              <span className="text-sm font-medium">18%</span>
            </li>
            <li className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="h-3 w-3 rounded-full bg-green-500 mr-3"></div>
                <span className="text-sm text-gray-600">IP Rights</span>
              </div>
              <span className="text-sm font-medium">14%</span>
            </li>
            <li className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="h-3 w-3 rounded-full bg-purple-500 mr-3"></div>
                <span className="text-sm text-gray-600">Confidentiality</span>
              </div>
              <span className="text-sm font-medium">12%</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;